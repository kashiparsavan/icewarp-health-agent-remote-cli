#!/bin/bash

###############################################################################
# =============================================================================
# SECTION 1: HEADER AND LICENSE
# =============================================================================
#
# PDF Report Writer (M5) - FINAL WITH VALIDATION
#
###############################################################################

# =============================================================================
# SECTION 2: CONSTANTS (Page dimensions, colors, margins)
# =============================================================================

PDF_PAGE_W=612
PDF_PAGE_H=792
PDF_MARGIN=36
PDF_TOP_Y=756
PDF_BOTTOM_Y=44
PDF_CONTENT_RIGHT=$((PDF_PAGE_W - PDF_MARGIN))
PDF_CONTENT_W=$((PDF_CONTENT_RIGHT - PDF_MARGIN))

PDF_C_NAVY="0.102 0.235 0.369"
PDF_C_WHITE="1 1 1"
PDF_C_TEXT="0.15 0.17 0.2"
PDF_C_GRAY_LIGHT="0.955 0.96 0.965"
PDF_C_GREEN="0.118 0.518 0.286"
PDF_C_RED="0.753 0.224 0.169"
PDF_C_AMBER="0.83 0.53 0.06"
PDF_C_BLUEGRAY="0.30 0.42 0.55"
PDF_C_GRAY="0.5 0.53 0.56"
PDF_C_VALUE="0.30 0.33 0.36"

PDF_CHECKLIST_VERSION="${CHECKLIST_VERSION:-1.14}"

# =============================================================================
# SECTION 3: HELPER FUNCTIONS
# =============================================================================

_is_num() { [[ "$1" =~ ^-?[0-9]+(\.[0-9]+)?$ ]]; }

_pdf_escape() {
    local S="$1"
    S="$(printf '%s' "$S" | LC_ALL=C tr -c '\40-\176' '?')"
    S="${S//\\/\\\\}"
    S="${S//(/\\(}"
    S="${S//)/\\)}"
    printf '%s' "$S"
}

_pdf_rect() {
    _PDF_CUR="${_PDF_CUR}${5} rg"$'\n'
    _PDF_CUR="${_PDF_CUR}${1} ${2} ${3} ${4} re f"$'\n'
}

_pdf_text() {
    local ESC
    ESC="$(_pdf_escape "$3")"
    _PDF_CUR="${_PDF_CUR}${6} rg"$'\n'
    _PDF_CUR="${_PDF_CUR}BT /${4} ${5} Tf ${1} ${2} Td (${ESC}) Tj ET"$'\n'
}

_pdf_text_trunc() {
    local MAXCHARS="$7"
    local TXT="$3"
    [ "${#TXT}" -gt "$MAXCHARS" ] && TXT="${TXT:0:$((MAXCHARS-1))}."
    _pdf_text "$1" "$2" "$TXT" "$4" "$5" "$6"
}

# _pdf_note_lines <text> <maxchars> -> prints up to 2 wrapped lines (newline
# separated). A single over-long word is truncated, never emitted as a blank
# first line, so a long note never pushes its baseline off the row.
_pdf_note_lines() {
    local TEXT="$1" MAXC="$2" LINE="" CAND="" W
    local -a LINES=()
    for W in $TEXT; do
        if [ -z "$LINE" ]; then CAND="$W"; else CAND="${LINE} ${W}"; fi
        if [ "${#CAND}" -le "$MAXC" ]; then
            LINE="$CAND"
        else
            if [ -z "$LINE" ]; then LINE="${W:0:$((MAXC-3))}..."; fi
            LINES+=("$LINE"); LINE="$W"
            [ "${#LINES[@]}" -ge 2 ] && break
        fi
    done
    [ -n "$LINE" ] && LINES+=("$LINE")
    [ "${#LINES[@]}" -eq 0 ] && LINES+=("")
    printf '%s\n' "${LINES[@]}"
}

# =============================================================================
# SECTION 4: PAGE MANAGEMENT
# =============================================================================

_PDF_PAGES=()
_PDF_CUR=""
_PDF_Y=$PDF_TOP_Y

_layout_new_page() {
    [ -n "$_PDF_CUR" ] && _PDF_PAGES+=("$_PDF_CUR")
    _PDF_CUR=""
    _PDF_Y=$PDF_TOP_Y
}

_layout_ensure() {
    local NEEDED="$1"
    [ "$((_PDF_Y - NEEDED))" -lt "$PDF_BOTTOM_Y" ] && _layout_new_page
}

_layout_finish() {
    [ -n "$_PDF_CUR" ] && _PDF_PAGES+=("$_PDF_CUR")
}

_layout_section_header() {
    local TITLE="$1"
    _layout_ensure 100
    _PDF_Y=$((_PDF_Y - 6))
    _pdf_rect "$PDF_MARGIN" "$((_PDF_Y - 18))" "$PDF_CONTENT_W" 22 "$PDF_C_NAVY"
    _pdf_text "$((PDF_MARGIN + 8))" "$((_PDF_Y - 12))" "$TITLE" "F2" 11 "$PDF_C_WHITE"
    _PDF_Y=$((_PDF_Y - 30))
}

# =============================================================================
# SECTION 5: BADGE COLOR AND ROW RENDERER
# =============================================================================

_badge_color() {
    case "$1" in
        PASS)      echo "$PDF_C_GREEN" ;;
        CRITICAL)  echo "$PDF_C_RED" ;;
        WARN)      echo "$PDF_C_AMBER" ;;
        INFO)      echo "$PDF_C_BLUEGRAY" ;;
        *)         echo "$PDF_C_GRAY" ;;
    esac
}

_layout_row_index=0

_layout_row() {
    local LABEL="$1" VALUE="$2" BKIND="$3" BTEXT="$4" NOTE="${5:-}"
    # Value column widened from 34 to 46 chars so "Total(KB)=<n> / Available
    # KB=<n>" and "Total(GB)=<n> / Used %=<n>" are never cut off. The badge
    # still clears: 46 chars at 9pt ~ 207u from x=276 ends at 483, badge at 496.
    local ROW_H=16
    # Compromise note-row height: tall enough for the two wrapped note lines and
    # their descenders, short enough that the ~100 checklist rows do not blow the
    # page count out. 20 is the floor; a two-line note's descender reaches
    # ROW_TOP-37 against a rect bottom of ROW_TOP-36, so raise to 24 if descents
    # reappear.
    [ -n "$NOTE" ] && ROW_H=20
    _layout_ensure "$ROW_H"
    local BG="$PDF_C_WHITE"
    [ $(( _layout_row_index % 2 )) -eq 1 ] && BG="$PDF_C_GRAY_LIGHT"
    _layout_row_index=$((_layout_row_index + 1))
    local ROW_TOP=$_PDF_Y
    _pdf_rect "$PDF_MARGIN" "$((ROW_TOP - ROW_H + 4))" "$PDF_CONTENT_W" "$ROW_H" "$BG"
    local TEXT_Y=$((ROW_TOP - 11))
    _pdf_text_trunc "$((PDF_MARGIN + 8))" "$TEXT_Y" "$LABEL" "F1" 9 "$PDF_C_TEXT" 46
    _pdf_text_trunc "$((PDF_MARGIN + 240))" "$TEXT_Y" "$VALUE" "F1" 9 "$PDF_C_VALUE" 46
    local BADGE_W=76 BADGE_H=13
    local BADGE_X=$((PDF_CONTENT_RIGHT - BADGE_W - 4))
    local BADGE_Y=$((ROW_TOP - 12))
    local BCOLOR
    BCOLOR="$(_badge_color "$BKIND")"
    _pdf_rect "$BADGE_X" "$BADGE_Y" "$BADGE_W" "$BADGE_H" "$BCOLOR"
    _pdf_text_trunc "$((BADGE_X + 6))" "$((BADGE_Y + 4))" "$BTEXT" "F2" 7.5 "$PDF_C_WHITE" 14
    if [ -n "$NOTE" ]; then
        # Notes are no longer clipped at 100 chars: they wrap to two lines, and
        # the second line sits high enough that its descender clears the row.
        local -a NLINES=()
        local N1 N2
        N1="$(_pdf_note_lines "note: ${NOTE}" 100 | head -n1)"
        N2="$(_pdf_note_lines "note: ${NOTE}" 100 | sed -n '2p')"
        _pdf_text "$((PDF_MARGIN + 8))" "$((TEXT_Y - 11))" "$N1" "F3" 7.5 "$PDF_C_GRAY"
        [ -n "$N2" ] && _pdf_text "$((PDF_MARGIN + 8))" "$((TEXT_Y - 24))" "$N2" "F3" 7.5 "$PDF_C_GRAY"
    fi
    _PDF_Y=$((_PDF_Y - ROW_H))
}

_layout_plain_line() {
    _layout_ensure 12
    _pdf_text_trunc "$PDF_MARGIN" "$_PDF_Y" "$1" "F1" 8.5 "$PDF_C_TEXT" 110
    _PDF_Y=$((_PDF_Y - 12))
}

# ---------- Appendix table helpers ----------

_pdf_clean_value() {
    printf '%s' "$1" | tr '\r\n\t' '   ' | sed 's/  */ /g; s/^ //; s/ $//'
}

_appendix_category() {
    case "$1" in
        agent.*|general.*)                 echo "Agent & General" ;;
        dns.*)                             echo "DNS & Mail Flow" ;;
        icewarp.*)                         echo "IceWarp Server" ;;
        smtp.*|queue.*)                    echo "SMTP & Delivery" ;;
        security.*|antispam.*)             echo "Security & Intrusion Prevention" ;;
        backup.*|archive.*)                echo "Backup & Archive" ;;
        watchdog.*|monitor.*)              echo "Watchdog & Monitoring" ;;
        os.*|storage.*|system.*)           echo "OS, Storage & Resources" ;;
        database.*|mysql.*)                echo "Database" ;;
        fulltext.*|logging.*|admin.*|directory_cache.*) echo "Services, Logging & Admin" ;;
        domain.*)                          echo "Domains" ;;
        health.*)                          echo "Health Evaluation" ;;
        http.*)                            echo "HTTP / API" ;;
        *)                                 echo "Other" ;;
    esac
}

_layout_appendix_header() {
    local TITLE="$1"
    _layout_ensure 34
    _PDF_Y=$((_PDF_Y - 8))
    _pdf_rect "$PDF_MARGIN" "$((_PDF_Y - 16))" "$PDF_CONTENT_W" 16 "0.93 0.95 0.97"
    _pdf_rect "$PDF_MARGIN" "$((_PDF_Y - 16))" 3 16 "$PDF_C_BLUEGRAY"
    _pdf_text "$((PDF_MARGIN + 7))" "$((_PDF_Y - 11))" "$TITLE" "F2" 8.5 "$PDF_C_NAVY"
    _PDF_Y=$((_PDF_Y - 19))
}

_layout_kv_header() {
    _layout_ensure 16
    _pdf_rect "$PDF_MARGIN" "$((_PDF_Y - 14))" "$PDF_CONTENT_W" 14 "$PDF_C_NAVY"
    _pdf_text "$((PDF_MARGIN + 5))" "$((_PDF_Y - 10))" "KEY" "F2" 6.8 "$PDF_C_WHITE"
    _pdf_text "$((PDF_MARGIN + 225))" "$((_PDF_Y - 10))" "VALUE" "F2" 6.8 "$PDF_C_WHITE"
    _PDF_Y=$((_PDF_Y - 14))
}

_APPENDIX_CAT=""

_layout_kv_row() {
    local KEY="$1" VALUE="$2"
    local ROW_H=14
    local BEFORE=${#_PDF_PAGES[@]}
    _layout_ensure "$ROW_H"
    if [ "${#_PDF_PAGES[@]}" -ne "$BEFORE" ] && [ -n "$_APPENDIX_CAT" ]; then
        _layout_appendix_header "$_APPENDIX_CAT"
        _layout_kv_header
    fi
    local BG="$PDF_C_WHITE"
    [ $(( _layout_row_index % 2 )) -eq 1 ] && BG="$PDF_C_GRAY_LIGHT"
    _layout_row_index=$((_layout_row_index + 1))
    _pdf_rect "$PDF_MARGIN" "$((_PDF_Y - ROW_H + 3))" "$PDF_CONTENT_W" "$ROW_H" "$BG"
    _pdf_text_trunc "$((PDF_MARGIN + 5))" "$((_PDF_Y - 7))" "$KEY" "F1" 7.2 "$PDF_C_TEXT" 54
    _pdf_text_trunc "$((PDF_MARGIN + 225))" "$((_PDF_Y - 7))" "$(_pdf_clean_value "$VALUE")" "F1" 7.2 "$PDF_C_VALUE" 82
    _PDF_Y=$((_PDF_Y - ROW_H))
}

# =============================================================================
# SECTION 6: COVER PAGE
# =============================================================================

_layout_cover() {
    local HOST="${DATA[agent.hostname]:-unknown}"
    local GEN="${DATA[agent.time]:-unknown}"
    local VER="${DATA[agent.version]:-unknown}"
    local OVERALL="${DATA[health.summary.overall]:-n/a}"
    local FAILED="${DATA[health.summary.failed]:-0}"
    local WARNINGS="${DATA[health.summary.warnings]:-0}"
    local CHECKED="${DATA[health.summary.total_checks]:-0}"

    _pdf_rect 0 692 "$PDF_PAGE_W" 100 "$PDF_C_NAVY"
    _pdf_text "$PDF_MARGIN" 754 "IceWarp Health Check Report" "F2" 22 "$PDF_C_WHITE"
    _pdf_text "$PDF_MARGIN" 730 "Based on IceWarp CheckList v${PDF_CHECKLIST_VERSION}" "F3" 12 "$PDF_C_WHITE"
    _pdf_text "$PDF_MARGIN" 706 "Host: ${HOST}   Generated: ${GEN}   Agent v${VER}" "F1" 9.5 "$PDF_C_WHITE"

    _PDF_Y=660
    local LIC_TYPE="${DATA[icewarp.license.type]:-unknown}"
    local LIC_EXP="${DATA[icewarp.license.trial_expiration]:-}"
    local LIC_DISPLAY
    if [ -n "$LIC_EXP" ]; then
        LIC_DISPLAY="${LIC_EXP}"
    elif [ "$LIC_TYPE" = "Evaluation" ]; then
        LIC_DISPLAY="Evaluation (expiration not detected)"
    else
        LIC_DISPLAY="N/A (perpetual license)"
    fi

    local INFO_ROWS=(
        "Company Name|${DATA[general.company]:-Unknown}"
        "Mail Domain|${DATA[domain.primary.name]:-not returned}"
        "Technician|${DATA[general.technician]:-Parsavan}"
        "IceWarp Version|${DATA[icewarp.version]:-unknown}"
        "Antispam Last Update|${DATA[icewarp.antispam.last_update]:-unknown}"
        "Antivirus Last Update|${DATA[icewarp.antivirus.last_update]:-unknown}"
        "Last Backup Date/Time|${DATA[icewarp.backup.last_time]:-unknown}"
        "License Type|${LIC_TYPE}"
        "License Expiration|${LIC_DISPLAY}"
        "SSL Expiration|${DATA[icewarp.ssl.expiration]:-not returned}"
    )
    local ROW
    for ROW in "${INFO_ROWS[@]}"; do
        local LBL="${ROW%%|*}"
        local VAL="${ROW#*|}"
        _pdf_text "$((PDF_MARGIN + 8))" "$_PDF_Y" "${LBL}:" "F2" 9.5 "$PDF_C_TEXT"
        _pdf_text_trunc "$((PDF_MARGIN + 190))" "$_PDF_Y" "$VAL" "F1" 9.5 "$PDF_C_GRAY" 55
        _PDF_Y=$((_PDF_Y - 16))
    done

    _PDF_Y=$((_PDF_Y - 14))
    local BANNER_COLOR
    case "$OVERALL" in
        pass) BANNER_COLOR="$PDF_C_GREEN" ;;
        warn) BANNER_COLOR="$PDF_C_AMBER" ;;
        fail) BANNER_COLOR="$PDF_C_RED" ;;
        *) BANNER_COLOR="$PDF_C_GRAY" ;;
    esac
    _pdf_rect "$PDF_MARGIN" "$((_PDF_Y - 44))" "$PDF_CONTENT_W" 44 "$BANNER_COLOR"
    _pdf_text "$((PDF_MARGIN + 14))" "$((_PDF_Y - 20))" "OVERALL: $(echo "$OVERALL" | tr '[:lower:]' '[:upper:]')" "F2" 15 "$PDF_C_WHITE"
    _pdf_text "$((PDF_MARGIN + 14))" "$((_PDF_Y - 36))" "${CHECKED} checks run across ${AREAS} areas  -  ${FAILED} failed  -  ${WARNINGS} warnings" "F1" 9 "$PDF_C_WHITE"
    _PDF_Y=$((_PDF_Y - 60))

    _pdf_text "$PDF_MARGIN" "$_PDF_Y" "Legend:" "F2" 8.5 "$PDF_C_TEXT"
    local LX=$((PDF_MARGIN + 46))
    local LEGEND_ITEMS=("PASS:Green" "CRITICAL:Red" "WARN:Orange" "INFO:Purple")
    local ITEM
    for ITEM in "${LEGEND_ITEMS[@]}"; do
        local STATUS="${ITEM%%:*}"
        local BC
        case "$STATUS" in
            PASS) BC="$PDF_C_GREEN" ;;
            CRITICAL) BC="$PDF_C_RED" ;;
            WARN) BC="$PDF_C_AMBER" ;;
            INFO) BC="$PDF_C_BLUEGRAY" ;;
        esac
        _pdf_rect "$LX" "$((_PDF_Y - 3))" 26 11 "$BC"
        _pdf_text "$((LX + 30))" "$_PDF_Y" "$STATUS" "F1" 8 "$PDF_C_TEXT"
        LX=$((LX + 30 + 6*${#STATUS} + 14))
    done
    _PDF_Y=$((_PDF_Y - 20))
}

# =============================================================================
# SECTION 7: HEALTH SUMMARY RENDERER
# =============================================================================

_render_health_summary() {
    _layout_section_header "Health Summary"
    _layout_row_index=0
    _layout_plain_line "Nine executive control areas. Detailed evidence follows in the checklist."

    local -a SUMMARY_ITEMS=(
        "backup|Backup & Recovery"
        "mail_flow|Mail Flow & DNS"
        "tls|Transport Security"
        "access|Access & Authentication"
        "threat|Threat Protection"
        "resources|Server Resources"
        "os_update|OS & Patching"
        "monitoring|Monitoring & Watchdog"
        "database|Database Platform"
    )

    for ITEM in "${SUMMARY_ITEMS[@]}"; do
        local KEY="${ITEM%%|*}"
        local TITLE="${ITEM##*|}"
        local RESULT="${HEALTH[$KEY]:-skip}"
        [ "$RESULT" = "skip" ] && continue
        local BKIND
        case "$RESULT" in
            pass) BKIND="PASS" ;;
            warn) BKIND="WARN" ;;
            fail|critical) BKIND="CRITICAL" ;;
            *) BKIND="INFO" ;;
        esac
        _layout_row "$TITLE" "" "$BKIND" "$BKIND" "${HEALTH_MSG[$KEY]:-}"
    done
}

# =============================================================================
# SECTION 8: DATE, VALUE RENDER, INTRUSION VALIDATION HELPERS
# =============================================================================

# _days_ago / norm_date live in lib/common.sh (single copy)

_cl_value_render() {
    local KEYS="$1"
    if [[ "$KEYS" == *,* ]]; then
        local -a PARTS=()
        local K SHORT
        IFS=',' read -ra _KARR <<< "$KEYS"
        for K in "${_KARR[@]}"; do
            SHORT="${K##*.}"
            PARTS+=("${SHORT}=${DATA[$K]:-?}")
        done
        local JOINED
        JOINED="$(IFS=', '; echo "${PARTS[*]}")"
        printf '%s' "$JOINED"
    else
        printf '%s' "${DATA[$KEYS]:-(empty)}"
    fi
}

# =============================================================================
# SECTION 9: MAIN CHECKLIST RENDERER
# =============================================================================

_render_checklist() {
    local CHECKLIST_FILE="${PROJECT_ROOT}/config/checklist.conf.pdf"
    local CUR_SECTION=""

    if [ ! -f "$CHECKLIST_FILE" ]; then
        _layout_plain_line "Checklist file not found: $CHECKLIST_FILE"
        return
    fi

    while IFS= read -r line; do
        [ -z "$line" ] && continue
        line=$(echo "$line" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [ -z "$line" ] && continue

        IFS='~' read -r SECTION LABEL KIND KEYS NOTE <<< "$line"

        if [ "$SECTION" != "$CUR_SECTION" ]; then
            _layout_section_header "$SECTION"
            CUR_SECTION="$SECTION"
            _layout_row_index=0
        fi

        # ---- Special case: MySQL Server section ----
        if [[ "$SECTION" == "MySQL Server"* ]] && [ "${DATA[database.scope]:-}" != "remote" ]; then
            local NA_REASON="not applicable"
            case "${DATA[database.type]:-}" in
                sqlite) NA_REASON="not applicable - this install uses SQLite, no MySQL server involved" ;;
                mysql) NA_REASON="not applicable - MySQL runs locally on this same server, see the Database section above" ;;
                *) NA_REASON="not applicable - database type could not be determined" ;;
            esac
            _layout_row "$LABEL" "N/A" "INFO" "INFO" "$NA_REASON"
            continue
        fi

        # ---- Special case: MySQL items in Database section ----
        if [[ "$SECTION" == "Database" ]] && [[ "$LABEL" == MySQL* ]] && [[ "${DATA[mysql.applicable]:-false}" != "true" ]]; then
            _layout_row "$LABEL" "N/A" "INFO" "INFO" "MySQL is not installed/running on this server"
            continue
        fi

        # ---- Health-backed rows: status comes from lib/health.sh (no thresholds here) ----
        if health_row_for_label "$LABEL" "$NOTE"; then
            _layout_row "$LABEL" "$HR_VALUE" "$HR_KIND" "$HR_KIND" "$HR_NOTE"
            continue
        fi

        # ---- Special case: Hide Server Version ----
        if [ "$LABEL" = "Hide Server Version" ]; then
            local RAW="${DATA[smtp.hide_server_version]:-}"
            if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                _layout_row "$LABEL" "Enabled" "PASS" "PASS" "$NOTE"
            else
                _layout_row "$LABEL" "Disabled" "CRITICAL" "CRITICAL" "$NOTE"
            fi
            continue
        fi

        # ---- Special case: Port 9001 ----
        if [ "$LABEL" = "Block Outgoing Port 9001" ]; then
            local RAW="${DATA[security.port_9001_egress.blocked]:-}"
            if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                _layout_row "$LABEL" "Blocked" "PASS" "PASS" "$NOTE"
            else
                _layout_row "$LABEL" "Not Blocked" "CRITICAL" "CRITICAL" "$NOTE"
            fi
            continue
        fi

        # ---- Special case: AntiSpam Live ----
        if [ "$LABEL" = "Disable AntiSpam Live" ]; then
            local RAW="${DATA[security.antispam_live.enabled]:-}"
            if [[ "$RAW" == "0" ]] || [[ "$RAW" == "false" ]] || [[ "$RAW" == "FALSE" ]] || [[ "$RAW" == "False" ]]; then
                _layout_row "$LABEL" "YES" "PASS" "PASS" "$NOTE"
            else
                _layout_row "$LABEL" "NO" "WARN" "WARN" "$NOTE"
            fi
            continue
        fi

        # ---- Special case: Process POP3/IMAP ----
        if [ "$LABEL" = "Process POP3/IMAP" ]; then
            local RAW="${DATA[security.intrusion.process_pop3_imap]:-0}"
            if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                _layout_row "$LABEL" "Enabled" "PASS" "PASS" "$NOTE"
            else
                _layout_row "$LABEL" "Disabled" "CRITICAL" "CRITICAL" "$NOTE"
            fi
            continue
        fi

        # ---- Special case: Cloud Features (CHANGED to WARN for enabled) ----
        if [ "$LABEL" = "Disable Cloud Features" ]; then
            local RAW="${DATA[icewarp.cloud_api.autoconfigure]:-}"
            if [[ "$RAW" == "0" ]] || [[ "$RAW" == "false" ]] || [[ "$RAW" == "FALSE" ]] || [[ "$RAW" == "False" ]]; then
                _layout_row "$LABEL" "Disabled" "PASS" "PASS" "$NOTE"
            elif [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                _layout_row "$LABEL" "Enabled" "WARN" "WARN" "$NOTE"
            else
                _layout_row "$LABEL" "N/A" "INFO" "INFO" "$NOTE"
            fi
            continue
        fi

        # ---- Special case: VRFY ----
        if [ "$LABEL" = "Disable VRFY" ]; then
            local RAW="${DATA[smtp.deny_vrfy]:-}"
            if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                _layout_row "$LABEL" "Disabled" "PASS" "PASS" "$NOTE"
            elif [[ "$RAW" == "0" ]] || [[ "$RAW" == "false" ]] || [[ "$RAW" == "FALSE" ]] || [[ "$RAW" == "False" ]]; then
                _layout_row "$LABEL" "Enabled" "CRITICAL" "CRITICAL" "$NOTE"
            else
                _layout_row "$LABEL" "Unknown" "CRITICAL" "CRITICAL" "VRFY setting not detected - please verify manually"
            fi
            continue
        fi

        # ---- Special case: License ----
        if [ "$LABEL" = "Number of Used Seats / License Max Users" ]; then
            local RAW="${DATA[icewarp.license.used_seats_note]:-}"
            if [ -z "$RAW" ] || [[ "$RAW" == *"not available"* ]]; then
                _layout_row "$LABEL" "unavailable" "WARN" "WARN" "Unable to retrieve license usage - check via Admin API"
            else
                _layout_row "$LABEL" "$RAW" "INFO" "INFO" "$NOTE"
            fi
            continue
        fi

        # ---- Special case: Daytime Clock ----
        if [ "$LABEL" = "Enable Daytime Clock Synchronization" ]; then
            local RAW="${DATA[icewarp.daytime_clock_sync.enabled]:-}"
            if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                _layout_row "$LABEL" "Enabled" "PASS" "PASS" "$NOTE"
            elif [[ "$RAW" == "0" ]] || [[ "$RAW" == "false" ]] || [[ "$RAW" == "FALSE" ]] || [[ "$RAW" == "False" ]]; then
                _layout_row "$LABEL" "Disabled" "CRITICAL" "CRITICAL" "$NOTE"
            else
                _layout_row "$LABEL" "Unknown" "WARN" "WARN" "Daytime sync setting not detected - please verify manually"
            fi
            continue
        fi

        # ---- NEW: Special case for Integrate Archive with IMAP Folder (show value) ----
        if [ "$LABEL" = "Integrate Archive with IMAP Folder" ]; then
            local RAW="${DATA[archive.integrate_with_imap]:-0}"
            local VALUE=""
            local BKIND="INFO"
            local BTEXT="INFO"
            local MSG=""
            if [ "$RAW" = "1" ]; then
                BKIND="PASS"; BTEXT="PASS"
                VALUE="Enabled"
                MSG="Integrate archive with IMAP folder: Archive"
            else
                BKIND="CRITICAL"; BTEXT="CRITICAL"
                VALUE="Disabled"
                MSG="Integrate archive with IMAP folder: Disabled"
            fi
            _layout_row "$LABEL" "$VALUE" "$BKIND" "$BTEXT" "$MSG"
            continue
        fi

        # ============================================================
        # IMPORTANT: Intrusion Prevention validation
        # MUST be checked BEFORE general KIND=V handling
        # ============================================================
        # ============================================================
        # APP OS / Infrastructure items (KIND=V with specific LABELs)
        # ============================================================
        if [ "$KIND" = "V" ]; then
            case "$LABEL" in
                "Database Scope")
                    local SCOPE="${DATA[database.scope]:-unknown}"
                    local VALUE="${SCOPE}"
                    local BKIND="PASS"
                    local BTEXT="PASS"
                    local MSG="Database scope: ${SCOPE}"
                    _layout_row "$LABEL" "$VALUE" "$BKIND" "$BTEXT" "$MSG"
                    continue
                    ;;
            esac
            # Fallback for generic V items
            local VAL="$(_cl_value_render "$KEYS")"
            _layout_row "$LABEL" "$VAL" "INFO" "INFO" "$NOTE"
            continue
        fi

        # ============================================================
        # Other KIND types (T, F, B, R, L, Z, M, G, P, W, D, H, etc.)
        # ============================================================

        if [ "$KIND" = "T" ]; then
            local RAW="${DATA[$KEYS]:-}"
            local EXPECTED="$NOTE"
            local BKIND="INFO"
            local BTEXT="INFO"
            local MSG=""
            if [ "$RAW" = "$EXPECTED" ]; then
                BKIND="PASS"
                BTEXT="PASS"
                MSG="Expected: $EXPECTED"
            else
                BKIND="WARN"
                BTEXT="WARN"
                MSG="Expected: $EXPECTED (current: $RAW)"
            fi
            _layout_row "$LABEL" "$RAW" "$BKIND" "$BTEXT" "$MSG"
            continue
        fi

        local RAW="${DATA[$KEYS]:-}"
        case "$KIND" in
            F)
                if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                    _layout_row "$LABEL" "Found" "PASS" "PASS" "$NOTE"
                elif [[ "$RAW" == "0" ]] || [[ "$RAW" == "false" ]] || [[ "$RAW" == "FALSE" ]] || [[ "$RAW" == "False" ]]; then
                    _layout_row "$LABEL" "Missing" "CRITICAL" "CRITICAL" "$NOTE"
                else
                    _layout_row "$LABEL" "N/A" "INFO" "INFO" "$NOTE"
                fi
                ;;
            B)
                if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                    _layout_row "$LABEL" "Enabled" "PASS" "PASS" "$NOTE"
                else
                    _layout_row "$LABEL" "Disabled" "CRITICAL" "CRITICAL" "$NOTE"
                fi
                ;;
            R)
                if [[ "$RAW" == "0" ]] || [[ "$RAW" == "false" ]] || [[ "$RAW" == "FALSE" ]] || [[ "$RAW" == "False" ]]; then
                    _layout_row "$LABEL" "No" "PASS" "PASS" "$NOTE"
                elif [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                    _layout_row "$LABEL" "Yes" "CRITICAL" "CRITICAL" "$NOTE"
                else
                    _layout_row "$LABEL" "N/A" "INFO" "INFO" "$NOTE"
                fi
                ;;
            L)
                if [[ -n "$RAW" ]] && [[ "$RAW" != "0" ]]; then
                    _layout_row "$LABEL" "Enabled (level $RAW)" "PASS" "PASS" "$NOTE"
                elif [[ "$RAW" == "0" ]]; then
                    _layout_row "$LABEL" "Disabled" "CRITICAL" "CRITICAL" "$NOTE"
                else
                    _layout_row "$LABEL" "N/A" "INFO" "INFO" "$NOTE"
                fi
                ;;
            Z)
                if [ "$RAW" = "0" ]; then
                    _layout_row "$LABEL" "Disabled" "WARN" "WARN" "${NOTE:-Backup emails is disabled (WARN)}"
                elif [ -n "$RAW" ]; then
                    _layout_row "$LABEL" "$RAW" "INFO" "INFO" "$NOTE"
                else
                    _layout_row "$LABEL" "not collected" "INFO" "INFO" "$NOTE"
                fi
                ;;
            M)
                if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                    _layout_row "$LABEL" "Yes" "WARN" "WARN" "$NOTE"
                else
                    _layout_row "$LABEL" "No" "PASS" "PASS" "$NOTE"
                fi
                ;;
            G)
                if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                    _layout_row "$LABEL" "Yes" "PASS" "PASS" "$NOTE"
                else
                    _layout_row "$LABEL" "No" "CRITICAL" "CRITICAL" "$NOTE"
                fi
                ;;
            P)
                if [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                    _layout_row "$LABEL" "Active" "CRITICAL" "CRITICAL" "$NOTE"
                else
                    _layout_row "$LABEL" "Off" "PASS" "PASS" "$NOTE"
                fi
                ;;
            W)
                _layout_row "$LABEL" "$RAW" "INFO" "INFO" "$NOTE"
                ;;
            D)
                # KIND D: 0/disabled = PASS, 1/enabled = WARN
                if [[ "$RAW" == "0" ]] || [[ "$RAW" == "false" ]] || [[ "$RAW" == "FALSE" ]] || [[ "$RAW" == "False" ]]; then
                    _layout_row "$LABEL" "Disabled" "PASS" "PASS" "$NOTE"
                elif [[ "$RAW" == "1" ]] || [[ "$RAW" == "true" ]] || [[ "$RAW" == "TRUE" ]] || [[ "$RAW" == "True" ]]; then
                    _layout_row "$LABEL" "Enabled" "WARN" "WARN" "$NOTE"
                else
                    _layout_row "$LABEL" "N/A" "INFO" "INFO" "$NOTE"
                fi
                ;;
            H)
                local WORST="pass"
                local MSGS=()
                IFS=',' read -ra _HKARR <<< "$KEYS"
                local K
                for K in "${_HKARR[@]}"; do
                    local RESULT="${HEALTH[$K]:-skip}"
                    [ -n "${HEALTH_MSG[$K]:-}" ] && MSGS+=("${HEALTH_MSG[$K]}")
                    case "$RESULT" in
                        fail|critical) WORST="fail" ;;
                        warn) [ "$WORST" != "fail" ] && WORST="warn" ;;
                    esac
                done
                local BKIND="INFO"
                case "$WORST" in
                    pass) BKIND="PASS" ;;
                    warn) BKIND="WARN" ;;
                    fail) BKIND="CRITICAL" ;;
                esac
                local JOINED_MSG
                JOINED_MSG="$(IFS='; '; echo "${MSGS[*]}")"
                _layout_row "$LABEL" "" "$BKIND" "$BKIND" "${JOINED_MSG:-$NOTE}"
                ;;
            *)
                if [ -n "$RAW" ]; then
                    _layout_row "$LABEL" "$RAW" "INFO" "INFO" "$NOTE"
                else
                    _layout_row "$LABEL" "N/A" "INFO" "INFO" "$NOTE"
                fi
                ;;
        esac
    done < "$CHECKLIST_FILE"
}

# =============================================================================
# SECTION 10: PDF LOW-LEVEL WRITER
# =============================================================================

_pdf_obj() {
    local NUM="$1"
    local CONTENT="$2"
    PDF_OFFSETS[$NUM]="$(wc -c < "$PDF_OUT_FILE")"
    printf '%s' "$CONTENT" >> "$PDF_OUT_FILE"
}

_pdf_write_file() {
    local OUT_PDF="$1"
    local P="${#_PDF_PAGES[@]}"
    [ "$P" -eq 0 ] && { echo "[WARN] build_pdf: nothing to render" >&2; return 1; }

    local F_REG=$((2 + 2*P + 1))
    local F_BOLD=$((2 + 2*P + 2))
    local F_OBL=$((2 + 2*P + 3))
    declare -Ag PDF_OFFSETS=()
    PDF_OUT_FILE="$OUT_PDF"

    : > "$OUT_PDF"
    printf '%%PDF-1.4\n' >> "$OUT_PDF"

    _pdf_obj 1 "1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
"

    local KIDS=""
    local i
    for ((i=1; i<=P; i++)); do
        KIDS="${KIDS}$((2+i)) 0 R "
    done
    _pdf_obj 2 "2 0 obj
<< /Type /Pages /Kids [ ${KIDS}] /Count ${P} >>
endobj
"

    for ((i=1; i<=P; i++)); do
        local PAGE_NUM=$((2+i))
        local CONTENT_NUM=$((2+P+i))
        local STREAM="${_PDF_PAGES[$((i-1))]}"
        if [ "$i" -gt 1 ]; then
            STREAM="${STREAM}0.80 0.83 0.87 RG
0.5 w
36 34 m 576 34 l S
${PDF_C_GRAY} rg
BT /F1 6.5 Tf 36 24 Td (IceWarp Health Check Report) Tj ET
BT /F1 6.5 Tf 536 24 Td (Page ${i} of ${P}) Tj ET
"
        fi
        local STREAM_LEN="$(printf '%s' "$STREAM" | wc -c)"

        _pdf_obj "$PAGE_NUM" "${PAGE_NUM} 0 obj
<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 ${F_REG} 0 R /F2 ${F_BOLD} 0 R /F3 ${F_OBL} 0 R >> >> /MediaBox [0 0 ${PDF_PAGE_W} ${PDF_PAGE_H}] /Contents ${CONTENT_NUM} 0 R >>
endobj
"

        _pdf_obj "$CONTENT_NUM" "${CONTENT_NUM} 0 obj
<< /Length ${STREAM_LEN} >>
stream
${STREAM}
endstream
endobj
"
    done

    _pdf_obj "$F_REG" "${F_REG} 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
"
    _pdf_obj "$F_BOLD" "${F_BOLD} 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>
endobj
"
    _pdf_obj "$F_OBL" "${F_OBL} 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique >>
endobj
"

    local XREF_START="$(wc -c < "$OUT_PDF")"
    local TOTAL_OBJS=$((F_OBL + 1))
    {
        printf 'xref\n0 %d\n' "$TOTAL_OBJS"
        printf '0000000000 65535 f \n'
        local n
        for ((n=1; n<=F_OBL; n++)); do
            printf '%010d 00000 n \n' "${PDF_OFFSETS[$n]}"
        done
        printf 'trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n' "$TOTAL_OBJS" "$XREF_START"
    } >> "$OUT_PDF"

    echo "[INFO] PDF report written: $OUT_PDF ($(wc -c < "$OUT_PDF") bytes, ${P} page(s))"
}

# =============================================================================
# SECTION 11: MAIN BUILDER
# =============================================================================

build_pdf() {
    local OUT_PDF="${OUTPUT_PDF:-${OUTPUT_DIR:-${HOME:-/root}/output}/report.pdf}"
    _PDF_PAGES=()
    _PDF_CUR=""
    _PDF_Y=$PDF_TOP_Y

    _layout_cover
    if [ "${#HEALTH[@]}" -gt 0 ] || [ -n "${DATA[watchdog.memory.status]:-}" ]; then
        _render_health_summary
    fi
    _layout_new_page
    _render_checklist

    _layout_ensure 80
    _layout_section_header "Collector Status"
    local K
    local FAILED_COLLECTORS=0
    _layout_row_index=0
    for K in $(printf '%s\n' "${!STATUS[@]}" | sort); do
        [ "${STATUS[$K]}" = "ok" ] && continue
        FAILED_COLLECTORS=$((FAILED_COLLECTORS+1))
        _layout_row "$K" "${STATUS_MSG[$K]:-}" "INFO" "${STATUS[$K]}" ""
    done
    [ "$FAILED_COLLECTORS" -eq 0 ] && _layout_plain_line "All collectors ran OK"

    _layout_new_page
    _layout_section_header "Appendix: Technical Data (${#DATA[@]} keys)"
    _layout_plain_line "Grouped by subsystem and sorted alphabetically. Raw keys are preserved for traceability."
    _layout_plain_line "Long values are truncated in this appendix; the JSON export contains the complete values."
    _APPENDIX_CAT=""

    local -a APPENDIX_CATS=(
        "Agent & General"
        "DNS & Mail Flow"
        "IceWarp Server"
        "SMTP & Delivery"
        "Security & Intrusion Prevention"
        "Backup & Archive"
        "Watchdog & Monitoring"
        "OS, Storage & Resources"
        "Database"
        "Services, Logging & Admin"
        "Domains"
        "HTTP / API"
        "Health Evaluation"
        "Other"
    )
    local APP_CAT APP_KEY
    for APP_CAT in "${APPENDIX_CATS[@]}"; do
        local -a APP_KEYS=()
        while IFS= read -r APP_KEY; do
            [ "$(_appendix_category "$APP_KEY")" = "$APP_CAT" ] || continue
            # health.<id>.message is a duplicate of the note already shown in the
            # Health Summary section; keep .result (and the pillar roll-ups, which
            # are also .result) and drop the messages to halve the appendix.
            [[ "$APP_KEY" == health.*.message ]] && continue
            APP_KEYS+=("$APP_KEY")
        done < <(printf '%s\n' "${!DATA[@]}" | sort)
        [ "${#APP_KEYS[@]}" -eq 0 ] && continue

        _APPENDIX_CAT="$APP_CAT"
        _layout_appendix_header "${APP_CAT}  (${#APP_KEYS[@]} keys)"
        _layout_row_index=0
        _layout_kv_header
        for APP_KEY in "${APP_KEYS[@]}"; do
            _layout_kv_row "$APP_KEY" "${DATA[$APP_KEY]}"
        done
        _PDF_Y=$((_PDF_Y - 6))
    done

    _layout_finish
    _pdf_write_file "$OUT_PDF"
}
