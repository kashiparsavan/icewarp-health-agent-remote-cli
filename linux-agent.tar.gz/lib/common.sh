#!/bin/bash

declare -Ag DATA
declare -Ag STATUS
declare -Ag STATUS_MSG

TOOL_TIMEOUT="${TOOL_TIMEOUT:-5}"

agent_init() {
    DATA=()
    STATUS=()
    STATUS_MSG=()
    DATA["agent.version"]="${AGENT_VERSION}"
    DATA["agent.hostname"]="$(hostname 2>/dev/null || echo unknown)"
    DATA["agent.time"]="$(date '+%F %T')"
    if [ -n "${COMPANY_NAME:-}" ]; then
        DATA["general.company"]="$COMPANY_NAME"
    fi
}

collector_set() {
    local KEY="$1"
    local VALUE="${2:-}"
    DATA["$KEY"]="$VALUE"
}

# ---------------------------------------------------------------------------
# Date and secret helpers (single shared copy - do NOT redefine elsewhere)
# ---------------------------------------------------------------------------

# norm_date <string> -> prints YYYY-MM-DD, returns 1 if empty/unparseable.
# Accepts: 2026-10-28[ 02:01:18]  |  27-10-26 (IceWarp Linux, D-M-YY)  |
#          10/25/2026 (Windows, M/D/YYYY; D/M/YYYY if first field > 12)
# GNU `date -d` must never see the raw IceWarp strings: "9-8-26" parses as
# year 0009 and "27-10-26" as 2027.
norm_date() {
    local s="${1:-}" y m d a b
    s="${s//\"/}"
    s="${s#"${s%%[![:space:]]*}"}"; s="${s%"${s##*[![:space:]]}"}"
    [ -z "$s" ] && return 1
    if [[ "$s" =~ ^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})([\ T].*)?$ ]]; then
        y=${BASH_REMATCH[1]} m=${BASH_REMATCH[2]} d=${BASH_REMATCH[3]}
    elif [[ "$s" =~ ^([0-9]{1,2})-([0-9]{1,2})-([0-9]{2}|[0-9]{4})$ ]]; then
        d=${BASH_REMATCH[1]} m=${BASH_REMATCH[2]} y=${BASH_REMATCH[3]}
    elif [[ "$s" =~ ^([0-9]{1,2})/([0-9]{1,2})/([0-9]{4})$ ]]; then
        a=${BASH_REMATCH[1]} b=${BASH_REMATCH[2]} y=${BASH_REMATCH[3]}
        if (( 10#$a > 12 )); then d=$a m=$b; else m=$a d=$b; fi
    else
        return 1
    fi
    (( 10#$y < 100 )) && y=$(( 2000 + 10#$y ))
    (( 10#$m >= 1 && 10#$m <= 12 && 10#$d >= 1 && 10#$d <= 31 )) || return 1
    printf '%04d-%02d-%02d' "$((10#$y))" "$((10#$m))" "$((10#$d))"
}

# _days_ago <string> -> whole days since the date (negative if in the future).
# Prints NOTHING and returns 1 when the date is empty/unparseable; callers must
# treat an empty result as "unknown" (warn), never as 0 or 999.
_days_ago() {
    local iso e
    iso="$(norm_date "${1:-}")" || return 1
    e="$(date -d "$iso" +%s 2>/dev/null)" || return 1
    echo $(( ( $(date +%s) - e ) / 86400 ))
}

# redact_dsn <dsn> -> IceWarp DSN "db;user;password;host;type;flag" with the
# password field (3) masked. Idempotent. SQLite DSNs pass through unchanged.
redact_dsn() {
    printf '%s' "${1:-}" | awk -F';' 'BEGIN{OFS=";"} { if ($3 != "") $3 = "***"; print }'
}

_RESOLVED_MAIL_HOSTNAME=""
resolve_mail_hostname() {
    if [ -n "${MAIL_HOSTNAME:-}" ]; then
        printf '%s' "$MAIL_HOSTNAME"
        return
    fi
    if [ -n "$_RESOLVED_MAIL_HOSTNAME" ]; then
        printf '%s' "$_RESOLVED_MAIL_HOSTNAME"
        return
    fi
    local DOMAIN
    DOMAIN="$(iw_list_domains | head -n1)"
    _RESOLVED_MAIL_HOSTNAME="$DOMAIN"
    printf '%s' "$DOMAIN"
}

# Domain that carries user mail. Used as the default company name in reports
# when --company is not supplied. Prefers the first real domain returned by
# IceWarp, then an operator override, then the configured public hostname.
resolve_mail_domain() {
    if [ -n "${DATA[domain.primary.name]:-}" ]; then
        printf '%s' "${DATA[domain.primary.name]}"
        return
    fi
    if [ -n "${MAIL_DOMAIN:-}" ]; then
        printf '%s' "$MAIL_DOMAIN"
        return
    fi
    local DOMAIN
    DOMAIN="$(iw_list_domains | head -n1)"
    if [ -z "$DOMAIN" ] && [ -n "${MAIL_HOSTNAME:-}" ]; then
        DOMAIN="$MAIL_HOSTNAME"
    fi
    printf '%s' "$DOMAIN"
}

# Mail host for STARTTLS probing: MAIL_HOSTNAME, else the primary domain's MX
# target, never just the first mail domain (which may not be the host that
# actually answers SMTP).
resolve_mail_mx() {
    local DOMAIN MX
    DOMAIN="$(resolve_mail_domain)"
    [ -z "$DOMAIN" ] && printf '%s' "$DOMAIN" && return 0
    MX="$(dig_resilient MX "$DOMAIN" 2>/dev/null | awk '{print $NF}' | grep -E '^[0-9]+$' | head -n1)"
    if [ -n "$MX" ]; then
        printf '%s' "$MX"
    else
        printf '%s' "$DOMAIN"
    fi
}

_RESOLVED_PUBLIC_IP=""
resolve_public_ip() {
    if [ -n "${MAIL_PUBLIC_IP:-}" ]; then
        printf '%s' "$MAIL_PUBLIC_IP"
        return
    fi
    if [ -n "$_RESOLVED_PUBLIC_IP" ]; then
        printf '%s' "$_RESOLVED_PUBLIC_IP"
        return
    fi
    local IP=""
    for SVC in "https://ifconfig.me" "https://icanhazip.com" "https://api.ipify.org" "https://ip.sb"; do
        IP="$(timeout 5 curl -s -4 --max-time 5 "$SVC" 2>/dev/null | tr -d '[:space:]')"
        [[ "$IP" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] && break
        IP=""
    done
    if [ -z "$IP" ]; then
        IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
        [ -n "$IP" ] && IP="${IP}(unconfirmed-local)"
    fi
    _RESOLVED_PUBLIC_IP="$IP"
    printf '%s' "$IP"
}

dig_resilient() {
    local ARGS=("$@")
    local RESULT
    RESULT="$(timeout "$TOOL_TIMEOUT" dig +short "${ARGS[@]}" 2>/dev/null)"
    if [ -n "$RESULT" ]; then
        printf '%s' "$RESULT"
        return
    fi
    for RESOLVER in 1.1.1.1 8.8.8.8; do
        RESULT="$(timeout "$TOOL_TIMEOUT" dig +short "${ARGS[@]}" "@${RESOLVER}" 2>/dev/null)"
        if [ -n "$RESULT" ]; then
            printf '%s' "$RESULT"
            return
        fi
    done
    printf ''
}

dns_txt_join() {
    local LINE="$1"
    local CHUNKS
    CHUNKS="$(printf '%s' "$LINE" | grep -oP '"[^"]*"')"
    if [ -n "$CHUNKS" ]; then
        printf '%s' "$CHUNKS" | tr -d '"' | tr -d '\n'
    else
        printf '%s' "$LINE" | tr -d '"'
    fi
}

# No lock functions needed - stateless execution

iw_get() {
    local TOOL_KEY="$1"
    local CONFIG_FILE="$2"
    local CONFIG_REGEX="$3"
    local OS_CMD="$4"
    local VALUE=""

    if [ -z "$VALUE" ] && [ -n "$TOOL_KEY" ] && [ -n "${IW_TOOL:-}" ] && [ -x "$IW_TOOL" ]; then
        VALUE="$(iw_tool_get "$TOOL_KEY")"
    fi

    if [ -z "$VALUE" ] && [ -n "$CONFIG_FILE" ] && [ -f "$CONFIG_FILE" ] && [ -n "$CONFIG_REGEX" ]; then
        VALUE="$(grep -oP "$CONFIG_REGEX" "$CONFIG_FILE" 2>/dev/null | head -n1)"
    fi

    if [ -z "$VALUE" ] && [ -n "$OS_CMD" ]; then
        VALUE="$(timeout "$TOOL_TIMEOUT" bash -c "$OS_CMD" 2>/dev/null)"
    fi

    printf '%s' "$VALUE"
}

iw_list_domains() {
    if [ -z "${IW_TOOL:-}" ] || [ ! -x "$IW_TOOL" ]; then
        return
    fi
    timeout "$TOOL_TIMEOUT" "$IW_TOOL" list domain 2>/dev/null \
        | tr -d '\r' \
        | grep -v '^##.*##$' \
        | grep -v '^\s*$'
}

iw_get_domain() {
    local DOMAIN="$1"
    local TOOL_KEY="$2"
    local CONFIG_FILE="$3"
    local CONFIG_REGEX="$4"
    local OS_CMD="$5"
    local VALUE=""

    if [ -z "$DOMAIN" ]; then
        printf ''
        return
    fi

    if [ -n "$TOOL_KEY" ] && [ -n "${IW_TOOL:-}" ] && [ -x "$IW_TOOL" ]; then
        local RAW
        RAW="$(timeout "$TOOL_TIMEOUT" "$IW_TOOL" display domain "$DOMAIN" "$TOOL_KEY" 2>/dev/null)"
        RAW="${RAW//$'\r'/}"
        VALUE="$(printf '%s\n' "$RAW" | grep "^${TOOL_KEY}:" | awk -F': ' '{print $2}' | head -n1)"
    fi

    if [ -z "$VALUE" ] && [ -n "$CONFIG_FILE" ] && [ -f "$CONFIG_FILE" ] && [ -n "$CONFIG_REGEX" ]; then
        VALUE="$(grep -oP "$CONFIG_REGEX" "$CONFIG_FILE" 2>/dev/null | head -n1)"
    fi

    if [ -z "$VALUE" ] && [ -n "$OS_CMD" ]; then
        VALUE="$(timeout "$TOOL_TIMEOUT" bash -c "$OS_CMD" 2>/dev/null)"
    fi

    printf '%s' "$VALUE"
}

iw_tool_get() {
    local KEY="$1"
    local RAW
    RAW="$(timeout 5 "$IW_TOOL" display system "$KEY" 2>/dev/null)"
    if [ -z "$RAW" ]; then
        printf ''
        return
    fi
    RAW="${RAW//$'\r'/}"
    printf '%s' "$RAW" | awk -F': ' '{print $2}' | head -n1
}

iw_tool_get_multiline() {
    local KEY="$1"
    local RAW
    RAW="$(timeout "$TOOL_TIMEOUT" "$IW_TOOL" display system "$KEY" 2>/dev/null)"
    RAW="${RAW//$'\r'/}"
    printf '%s' "$RAW" | sed '1s/^[^:]*:[[:space:]]*//'
}

run_collector() {
    local COLLECTOR_PATH="$1"
    local NAME="${COLLECTOR_PATH#$COLLECTOR_DIR/}"
    NAME="${NAME%.sh}"
    # Scratch file: prefer the dedicated agent workspace (/root/agent, created
    # by bootstrap.sh); fall back to TMPDIR only when it is unavailable, e.g.
    # when agent.sh is run directly by a non-root user.
    local ERR_DIR="${HEALTH_AGENT_DIR:-/root/agent}"
    [[ -d "$ERR_DIR" && -w "$ERR_DIR" ]] || ERR_DIR="${TMPDIR:-/tmp}"
    local ERR_FILE="$ERR_DIR/.collector_err.$$"

    source "$COLLECTOR_PATH"

    if ! declare -F collector_run >/dev/null; then
        unset -f collector_run 2>/dev/null
        return
    fi

    if collector_run 2>"$ERR_FILE"; then
        STATUS["$NAME"]="ok"
    else
        STATUS["$NAME"]="error"
        STATUS_MSG["$NAME"]="$(tail -n1 "$ERR_FILE" 2>/dev/null)"
    fi

    rm -f "$ERR_FILE"
    unset -f collector_run 2>/dev/null
}

list_collectors() {
    find "$COLLECTOR_DIR" -type f -name "*.sh" | \
        sed "s#${COLLECTOR_DIR}/##" | \
        sed 's#\.sh$##' | \
        sort
}

print_report() {
    echo
    echo "========================================"
    echo "IceWarp Health Check Report"
    echo "========================================"
    echo

    for KEY in $(printf "%s\n" "${!DATA[@]}" | sort)
    do
        printf "%-40s : %s\n" "$KEY" "${DATA[$KEY]}"
    done

    echo
    echo "Total Keys : ${#DATA[@]}"

    local FAILED=0
    for NAME in "${!STATUS[@]}"; do
        [ "${STATUS[$NAME]}" != "ok" ] && FAILED=$((FAILED+1))
    done

    if [ "$FAILED" -gt 0 ]; then
        echo
        echo "Collector issues (${FAILED}):"
        for NAME in $(printf "%s\n" "${!STATUS[@]}" | sort); do
            [ "${STATUS[$NAME]}" = "ok" ] && continue
            printf "  [%s] %-30s %s\n" "${STATUS[$NAME]}" "$NAME" "${STATUS_MSG[$NAME]:-}"
        done
    fi

    echo
}
